call allocate_gpu_memC(lbx, lby, nmat, mw1_pml1, mw2_pml1, nxtop, nytop, nztop, mw1_pml, mw2_pml, nxbtm, nybtm, nzbtm, nzbm1, nll)

