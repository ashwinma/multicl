#include<sys/time.h>
extern void record_time(struct timeval* tv_ptr);
extern float elapsed_time(struct timeval* start_tv, struct timeval* stop_tv) ;

